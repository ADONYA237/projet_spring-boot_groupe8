package com.ecommerce.core.controller;

import com.ecommerce.core.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1")
public class StatsController {

    @Autowired private ProductRepository productRepository;
    @Autowired private OrderRepository orderRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private CategoryRepository categoryRepository;

    @GetMapping("/stats")
    public Map<String, Object> getStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalProducts", productRepository.count());
        stats.put("totalOrders", orderRepository.count());
        stats.put("totalUsers", userRepository.count());
        stats.put("totalCategories", categoryRepository.count());
        
        double totalRevenue = orderRepository.findAll().stream()
                .filter(o -> "PAID".equals(o.getStatus()))
                .mapToDouble(o -> o.getTotalAmount())
                .sum();
        stats.put("totalRevenue", totalRevenue);
        
        return stats;
    }

    @GetMapping("/resources")
    public Map<String, List<String>> getResources() {
        Map<String, List<String>> resources = new HashMap<>();
        resources.put("endpoints", List.of(
            "GET /api/v1/products",
            "POST /api/v1/products",
            "GET /api/v1/categories",
            "POST /api/v1/categories",
            "POST /api/v1/users",
            "POST /api/v1/orders",
            "GET /api/v1/stats",
            "GET /api/v1/resources"
        ));
        resources.put("models", List.of("Product", "Category", "User", "Order", "Ticket", "Promotion"));
        return resources;
    }
}
