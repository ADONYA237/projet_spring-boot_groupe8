# Guide de Test des Workflows API v1

Ce document détaille les étapes pour tester les fonctionnalités clés de l'application. Le serveur doit être lancé sur le port **8081**.

---

## 1. Workflow de Configuration Initiale (Utilisateurs et Catégories)

### Créer des catégories
```bash
curl -X POST http://localhost:8081/api/v1/categories \
-H "Content-Type: application/json" \
-d '{
  "name": "Électronique",
  "description": "Appareils high-tech"
}'

curl -X POST http://localhost:8081/api/v1/categories \
-H "Content-Type: application/json" \
-d '{
  "name": "Promotions",
  "description": "Articles en solde"
}'
```

### Créer un utilisateur (Validation Camerounaise)
*Test avec un numéro valide :*
```bash
curl -X POST http://localhost:8081/api/v1/users \
-H "Content-Type: application/json" \
-d '{
  "username": "jean_dupont",
  "email": "jean@example.cm",
  "password": "password123",
  "phoneNumber": "+237670000000",
  "role": "CUSTOMER"
}'
```

*Test avec un numéro invalide (doit retourner une erreur 400) :*
```bash
curl -X POST http://localhost:8081/api/v1/users \
-H "Content-Type: application/json" \
-d '{
  "username": "bad_phone",
  "email": "bad@example.com",
  "password": "password123",
  "phoneNumber": "+33123456789"
}'
```

---

## 2. Workflow Produits (Multi-catégories et Recherche)

### Créer un produit avec plusieurs catégories
```bash
curl -X POST http://localhost:8081/api/v1/products \
-H "Content-Type: application/json" \
-d '{
  "name": "iPhone 15",
  "description": "Dernier smartphone Apple",
  "price": 1200.0,
  "stockQuantity": 10,
  "categories": [
    {"id": 1, "name": "Électronique"},
    {"id": 2, "name": "Promotions"}
  ]
}'
```

### Recherche Avancée
*Recherche par mot-clé :*
```bash
curl "http://localhost:8081/api/v1/products?keyword=Apple"
```

*Recherche par catégorie et prix :*
```bash
curl "http://localhost:8081/api/v1/products?category=Électronique&minPrice=1000&maxPrice=1500"
```

---

## 3. Workflow de Commande (Stock et Statut)

### Créer une commande
```bash
curl -X POST "http://localhost:8081/api/v1/orders?userId=1&address=Douala, Cameroun" \
-H "Content-Type: application/json" \
-d '[
  {
    "productId": 1,
    "quantity": 1
  }
]'
```

### Payer la commande
```bash
curl -X POST http://localhost:8081/api/v1/orders/1/pay
```

### Mettre à jour le statut de livraison
```bash
curl -X PATCH "http://localhost:8081/api/v1/orders/1/shipping?status=SHIPPED"
```

---

## 4. Workflow de Support (Tickets)

### Créer un ticket
```bash
curl -X POST http://localhost:8081/api/v1/tickets \
-H "Content-Type: application/json" \
-d '{
  "userId": 1,
  "subject": "Problème de livraison",
  "message": "Ma commande n'\''est toujours pas arrivée."
}'
```

### Voir tous les tickets
```bash
curl http://localhost:8081/api/v1/tickets
```

---

## 5. Workflow v3 (Facturation, Mail et Statistiques)

### Payer une commande (Déclenche Facture PDF + Mail)
*Note: Pour ce test, assurez-vous qu'un utilisateur avec un email valide existe.*
```bash
curl -X POST http://localhost:8081/api/v1/orders/1/pay
```

### Consulter les statistiques globales
```bash
curl http://localhost:8081/api/v1/stats
```

### Consulter les ressources du système
```bash
curl http://localhost:8081/api/v1/resources
```
